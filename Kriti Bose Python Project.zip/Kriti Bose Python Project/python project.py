#!/usr/bin/env python
# coding: utf-8

# # Task1: Find out the number of unique dialogue speaker in the sample conversation

# In[1]:


#Uploading the script
script=open('conv.txt', 'r')

#creating a list to store the unique speakers name
unique_list = []

#running a loop for reading the lines
for line in script.readlines():
    without_new_line=line.strip()
    #using split method to split the name which is separated by : 
    name=without_new_line.split(":" ,1)
    
    #checking the condition that no names should be repeated, using this 
    #condition to get the Unique Speaker Names.
    if name[0] not in unique_list: 
        if name[0]=='':
            continue
        else: 
        #appending list to store the names
            unique_list.append(name[0])
        
#Running For Loop to print the names of Unique Speaker       
for element in unique_list:
    print(element)
    


# In[2]:


#Finding the length of unique dialogue speaker
len(unique_list)


# # Task 2: Create a new text file by the name of the dialogue speaker and store the unique words spoken by that character in the respective text file. Make sure there is only one word every line.
# 

#  1. Will and his unique words

# In[3]:


#Uploading the script
script=open('conv.txt', 'r')
unique_word = []

#Here we are reading every line of the file
for line in script.readlines():
    
        #now checking the line actually belongs to the speaker
        if "WILL" in line:
            
            
            # opening a text file with append function which creates the files 
            W = open("WILL.txt", 'a')
            words = set(line.split())
            words = [word.strip('.,!;()[]') for word in words]
            words = [word.replace("'s", '') for word in words]
           
        
        #finding unique
            for word in words:
                if word not in unique_word:
                    unique_word.append(word)
                    W.write(word)
                    W.write('\n')
            W.close()


# In[4]:


words


#  2. WaymarRoyce and his unique words

# In[5]:


#Uploading the script
script=open('conv.txt', 'r')
unique_word = []

#reading every line of the file
for line in script.readlines():
    
        #now checking the line actually belongs to the speaker
        if "WAYMAR ROYCE" in line:
            
            
            #opening a text file with append function which creates the files 
            W = open("WAYMAR ROYCE.txt", 'a')
            words= set(line.split())
            words= [word.strip('.,!;()[]') for word in words]
            words= [word.replace("'s", '') for word in words]
           
        
        #finding unique
            for word in words:
                if word not in unique_word:
                    unique_word.append(word)
                    W.write(word)
                    W.write('\n')
            W.close()


# In[6]:


words


# 3. Gared and his unique words.

# In[7]:


#Uploading the script
script=open('conv.txt', 'r')
unique_word = []

#reading every line of the file
for line in script.readlines():
    
        #now checking the line actually belongs to the speaker
        if "GARED" in line:
            
            
            #opening a text file with append function which creates the files 
            G = open("GARED.txt", 'a')
            words = set(line.split())
            words = [word.strip('.,!;()[]') for word in words]
            words = [word.replace("'s", '') for word in words]
           
        
        #finding unique
            for word in words:
                if word not in unique_word:
                    unique_word.append(word)
                    G.write(word)
                    G.write('\n')
            G.close()


# In[8]:


words


# 4. Royce and his unique words.

# In[9]:


#Uploading the script
script=open('conv.txt', 'r')
unique_word = []

#reading every line of the file
for line in script.readlines():
    
        #now checking the line actually belongs to the speaker
        if "ROYCE" in line:
            
            
            #opening a text file with append function which creates the files 
            R = open("ROYCE.txt", 'a')
            words = set(line.split())
            words = [word.strip('.,!;()[]') for word in words]
            words = [word.replace("'s", '') for word in words]
           
        
        #finding unique
            for word in words:
                if word not in unique_word:
                    unique_word.append(word)
                    R.write(word)
                    R.write('\n')
            R.close()


# In[10]:


words


# 5. Jon and his unique words.

# In[11]:


#Uploading the script
script=open('conv.txt', 'r')
unique_word = []

#reading every line of the file
for line in script.readlines():
    
        #now checking the line actually belongs to the speaker
        if "JON" in line:
            
            
            #opening a text file with append function which creates the files 
            J = open("JON.txt", 'a')
            words = set(line.split())
            words = [word.strip('.,!;()[]') for word in words]
            words = [word.replace("'s", '') for word in words]
           
        
        #finding unique
            for word in words:
                if word not in unique_word:
                    unique_word.append(word)
                    J.write(word)
                    J.write('\n')
            J.close()


# In[12]:


words


# 6. Septa Mordane and her unique words.

# In[13]:


#Uploading the script
script=open('conv.txt', 'r')
unique_word = []

#reading every line of the file
for line in script.readlines():
    
        #now checking the line actually belongs to the speaker
        if "SEPTA MORDANE" in line:
            
            
            #opening a text file with append function which creates the files 
            S = open("SEPTA_MORDANE.txt", 'a')
            words = set(line.split())
            words = [word.strip('.,!;()[]') for word in words]
            words = [word.replace("'s", '') for word in words]
           
        
        #finding unique
            for word in words:
                if word not in unique_word:
                    unique_word.append(word)
                    S.write(word)
                    S.write('\n')
            S.close()


# In[14]:


words


# 7. Sansa and her unique words

# In[15]:


#Uploading the script
script=open('conv.txt', 'r')
unique_word = []

#reading every line of the file
for line in script.readlines():
    
        #now checking the line actually belongs to the speaker
        if "SANSA" in line:
            
            
            #opening a text file with append function which creates the files 
            S = open("SANSA.txt", 'a')
            words = set(line.split())
            words = [word.strip('.,!;()[]') for word in words]
            words = [word.replace("'s", '') for word in words]
           
        
        #finding unique
            for word in words:
                if word not in unique_word:
                    unique_word.append(word)
                    S.write(word)
                    S.write('\n')
            S.close()


# In[16]:


words


# 8. Ned and his unique words.

# In[17]:


#Uploading the script
script=open('conv.txt', 'r')
unique_word = []

#reading every line of the file
for line in script.readlines():
    
        #now checking the line actually belongs to the speaker
        if "NED" in line:
            
            
            #opening a text file with append function which creates the files 
            N = open("NED.txt", 'a')
            words = set(line.split())
            words = [word.strip('.,!;()[]') for word in words]
            words = [word.replace("'s", '') for word in words]
           
        
        #finding unique
            for word in words:
                if word not in unique_word:
                    unique_word.append(word)
                    N.write(word)
                    N.write('\n')
            N.close()


# In[18]:


words


# 9. Robb and his unique words

# In[19]:


#Uploading the script
script=open('conv.txt', 'r')
unique_word = []

#reading every line of the file
for line in script.readlines():
    
        #now checking the line actually belongs to the speaker
        if "ROBB" in line:
            
            
            #opening a text file with append function which creates the files 
            R = open("ROBB.txt", 'a')
            words = set(line.split())
            words = [word.strip('.,!;()[]') for word in words]
            words = [word.replace("'s", '') for word in words]
           
        
        #finding unique
            for word in words:
                if word not in unique_word:
                    unique_word.append(word)
                    R.write(word)
                    R.write('\n')
            R.close()


# In[20]:


words


# 10. Cassel and his unique words.

# In[21]:


#Uploading the script
script=open('conv.txt', 'r')
unique_word = []

#reading every line of the file
for line in script.readlines():
    
        #now checking the line actually belongs to the speaker
        if "CASSEL" in line:
            
            
            #opening a text file with append function which creates the files 
            C = open("CASSEL.txt", 'a')
            words = set(line.split())
            words = [word.strip('.,!;()[]') for word in words]
            words = [word.replace("'s", '') for word in words]
           
        
        #finding unique
            for word in words:
                if word not in unique_word:
                    unique_word.append(word)
                    C.write(word)
                    C.write('\n')
            C.close()


# In[22]:


words


# 11. Catelyn and her unique words.

# In[23]:


#Uploading the script
script=open('conv.txt', 'r')
unique_word = []

#reading every line of the file
for line in script.readlines():
    
        #now checking the line actually belongs to the speaker
        if "CATELYN" in line:
            
            
            #opening a text file with append function which creates the files 
            C = open("CATELYN.txt", 'a')
            words = set(line.split())
            words = [word.strip('.,!;()[]') for word in words]
            words = [word.replace("'s", '') for word in words]
           
        
        #finding unique
            for word in words:
                if word not in unique_word:
                    unique_word.append(word)
                    C.write(word)
                    C.write('\n')
            C.close()


# In[24]:


words


# 12. Bran and his unique words.

# In[25]:


#Uploading the script
script=open('conv.txt', 'r')
unique_word = []

#reading every line of the file
for line in script.readlines():
    
        #now checking the line actually belongs to the speaker
        if "BRAN" in line:
            
            
            #opening a text file with append function which creates the files 
            B = open("BRAN.txt", 'a')
            words = set(line.split())
            words = [word.strip('.,!;()[]') for word in words]
            words = [word.replace("'s", '') for word in words]
           
        
        #finding unique
            for word in words:
                if word not in unique_word:
                    unique_word.append(word)
                    B.write(word)
                    B.write('\n')
            B.close()


# In[26]:


words


# 13. Theon and his unique words

# In[27]:


#Uploading the script
script=open('conv.txt', 'r')
unique_word = []

#reading every line of the file
for line in script.readlines():
    
        #now checking the line actually belongs to the speaker
        if "THEON" in line:
            
            
            #opening a text file with append function which creates the files 
            T = open("THEON.txt", 'a')
            words = set(line.split())
            words = [word.strip('.,!;()[]') for word in words]
            words = [word.replace("'s", '') for word in words]
           
        
        #finding unique
            for word in words:
                if word not in unique_word:
                    unique_word.append(word)
                    T.write(word)
                    T.write('\n')
            T.close()


# In[28]:


words


# 14. Cersei and her unique words.

# In[29]:


#Uploading the script
script=open('conv.txt', 'r')
unique_word = []

#reading every line of the file
for line in script.readlines():
    
        #now checking the line actually belongs to the speaker
        if "CERSEI" in line:
            
            
            #opening a text file with append function which creates the files 
            C = open("CERSEI.txt", 'a')
            words = set(line.split())
            words = [word.strip('.,!;()[]') for word in words]
            words = [word.replace("'s", '') for word in words]
           
        
        #finding unique
            for word in words:
                if word not in unique_word:
                    unique_word.append(word)
                    C.write(word)
                    C.write('\n')
            C.close()


# In[30]:


words


# 15. Jaime and his unique words

# In[31]:


#Uploading the script
script=open('conv.txt', 'r')
unique_word = []

#reading every line of the file
for line in script.readlines():
    
        #now checking the line actually belongs to the speaker
        if "JAIME" in line:
            
            
            #opening a text file with append function which creates the files 
            J = open("JAIME.txt", 'a')
            words = set(line.split())
            words = [word.strip('.,!;()[]') for word in words]
            words = [word.replace("'s", '') for word in words]
           
        
        #finding unique
            for word in words:
                if word not in unique_word:
                    unique_word.append(word)
                    J.write(word)
                    J.write('\n')
            J.close()


# In[32]:


words


# 16. Robert and his unique words.

# In[33]:


#Uploading the script
script=open('conv.txt', 'r')
unique_word = []

#reading every line of the file
for line in script.readlines():
    
        #now checking the line actually belongs to the speaker.
        if "ROBERT" in line:
            
            
            #opening a text file with append function which creates the files 
            R = open("ROBERT.txt", 'a')
            words = set(line.split())
            words = [word.strip('.,!;()[]') for word in words]
            words = [word.replace("'s", '') for word in words]
           
        
        #finding unique
            for word in words:
                if word not in unique_word:
                    unique_word.append(word)
                    R.write(word)
                    R.write('\n')
            R.close()


# In[34]:


words


# 17. Arya and her unique words.

# In[35]:


#Uploading the script
script=open('conv.txt', 'r')
unique_word = []

#reading every line of the file
for line in script.readlines():
    
        #now checking the line actually belongs to the speaker
        if "ARYA" in line:
            
            
            #opening a text file with append function which creates the files 
            A = open("ARYA.txt", 'a')
            words = set(line.split())
            words = [word.strip('.,!;()[]') for word in words]
            words = [word.replace("'s", '') for word in words]
           
        
        #finding unique
            for word in words:
                if word not in unique_word:
                    unique_word.append(word)
                    A.write(word)
                    A.write('\n')
            A.close()


# In[36]:


words


# In[ ]:




